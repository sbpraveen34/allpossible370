/*
 * By using this file, you agree to the terms and conditions set
 * forth in the COPYING file which can be found at the top level
 * of this distribution.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <elf.h>

#include "fp.h"
#include "common.c"

char	*progname;

void usage(void)
{
	fprintf(stderr, "Usage:\n%s [-d] <filename>\n", progname);
	exit(2);
}

int main(int argc, char **argv)
{
	char	*filename = NULL, *opt = NULL;
	
	progname = argv[0];
	crc32_gentab();
	if (argc == 2) {
		filename= argv[1];
	} else
	if (argc == 3) {
		opt	= argv[1];
		filename= argv[2];
	} else
		usage();
	
	if (opt != NULL && strcmp(opt, "-d"))	
		usage();

	MMAP_FILE(MODE_READ, filename)
	
	FIND_TEXT

	island_t	*p, *islands;
	islands = find_islands(m + text_offset, m + text_offset + text_size);

	int	stat[15], total = 0, dump = 0, i;
	
	if (opt != NULL && !strcmp(opt, "-d"))
		dump = 1;
	printf("file: %s\n", filename);
	for (i = 0; i < 15; i++)
		stat[i] = 0;
	if (dump)
		printf("Found islands:\n");
	for (p = islands; p != NULL; p = p->next) {
		if (dump)
			printf("%08x %d\n", p->offset - (uint32_t)m - text_offset + text_addr, p->length);
		stat[p->length]++;
		total += p->length - 5;
	}
	for (i = 0; i < 15; i++) if (stat[i]) printf("%d\t", i);	putchar('\n');
	for (i = 0; i < 15; i++) if (stat[i]) printf("%d\t", stat[i]);	putchar('\n');
	printf("Total: %d bytes\n", total);

	return 0;
}
