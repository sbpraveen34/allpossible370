/*
 * By using this file, you agree to the terms and conditions set
 * forth in the COPYING file which can be found at the top level
 * of this distribution.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <elf.h>

#include "fp.h"
#include "common.c"

char *progname;

void usage(void)
{
	fprintf(stderr, "Usage:\n%s <snippet> <file>\n", progname);
	exit(2);
}

int main(int argc, char **argv)
{
	unsigned char	*codebuf;
	code_t		*code;

	crc32_gentab();
	progname = argv[0];
	if (argc != 3)
		usage();
	
	if ((codebuf = read_file(argv[1])) == NULL)
		return 2;
	if ((code = reassemble(codebuf)) == NULL)
		return 2;

	MMAP_FILE(MODE_WRITE, argv[2])
	
	FIND_TEXT

	island_t 	*islands;
	islands = find_islands(m + text_offset, m + text_offset + text_size);
	if (islands == NULL)
		printf("No free space!\n");

	island_t	*i;
	code_t		*c;
	
	for (i = islands, l = 0, c = code; c != NULL; )
	        if (l + c->len <= (i->length - 5)) {
			c->dst = (uint8_t*)(i->offset + l);
			memcpy(c->dst, c->src, c->len);
			l += c->len;
			c = c->next;
		} else {
			int n;
			for (n = l; n < i->length; n++)
				*((uint8_t*)(i->offset + n)) = 0x90;
			if (i->next != NULL) {
				*((uint8_t *)(i->offset + l))       = 0xe9;
				*((uint32_t*)(i->offset + l + 1))   = i->next->offset - i->offset - l - 5;
			} else {
				fprintf(stderr, "Failed to insert instr., no more space available!\n");
				return 2;
			}
			i = i->next;
			l = 0;
		}

	for (c = code; c != NULL; c = c->next)
		if (c->jmpto != 0) {
			code_t	*d;
			for (d = code; d != NULL; d = d->next)
				if (c->jmpto == d->src) {
					*((uint32_t*)(c->dst + c->len - 4)) = d->dst - c->dst - c->len;
					break;
				}
			if (d == NULL) {
				fprintf(stderr, "Unable to fix relative entity!\n");
				return 2;
			}
		}
#if 1
	*((uint32_t*)(code_ret->dst + 1)) = ehdr->e_entry - DST2VADDR(code_ret->dst) - 5;
	ehdr->e_entry	= DST2VADDR(code->dst);
#else
	if (firstcall == NULL)
		return 2;
	*((uint32_t*)(code_ret->dst + 1)) = DST2VADDR(firstcall) + *((uint32_t*)(firstcall + 1)) - DST2VADDR(code_ret->dst);
	*((uint32_t*)(firstcall + 1)) = DST2VADDR(code->dst) - DST2VADDR(firstcall) - 5;
#endif
	munmap(m, l);
	close(h);
	return 0;
}
