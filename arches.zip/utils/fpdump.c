/*
 * By using this file, you agree to the terms and conditions set
 * forth in the COPYING file which can be found at the top level
 * of this distribution.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <elf.h>

#include "fp.h"
#include "common.c"

char *progname;

void usage(void)
{
	fprintf(stderr,"Usage:\n%s <filename>\n", progname);
	exit(2);
}

int main(int argc, char **argv)
{
	unsigned char	*inbuf;

	progname = argv[0];
	if (argc < 2)
		usage();
	if ((inbuf = read_file(argv[1])) == NULL)
		return 2;

	code_t	*code = reassemble(inbuf);
	
	dump_code(code);
	return 0;
}
