/*
 * By using this file, you agree to the terms and conditions set
 * forth in the COPYING file which can be found at the top level
 * of this distribution.
 */
typedef struct _island island_t;
struct __attribute__((packed)) _island {
	uint32_t	offset;
	uint32_t	length;
	island_t	*next;
};

typedef struct _code code_t;
struct __attribute__((packed)) _code {
	uint8_t		*src;
	uint8_t		*dst;
	uint32_t	len;
	uint8_t		*jmpto;
	code_t		*next;
};

struct {
	int 		length;
	int		shift;
	uint32_t	crc32;
	unsigned char	bytes[16];
} patterns[] = {
	{15,	1,0x11d50a7f},
	{14,	1,0xe4ad564a},
	{15,	2,0xd5cae9dc},
	{13,	1,0xd6b6dcfd},
	{12,	1,0x19fbc1f4},
	{11,	1,0x34a6685b},
	{10,	1,0x74d8dd25},
	{9,	1,0x6ed89f27},
	{8,	1,0xb7109f48},
	{7,	1,0x5d30a0da},
};

extern int mlde32(void *p);

#define	FIND_TEXT						\
	Elf32_Ehdr	*ehdr = (Elf32_Ehdr*)m;			\
	Elf32_Shdr	*shdr, *s;				\
	uint32_t	strtab, text_addr = 0;			\
	uint32_t	text_size = 0, text_offset = 0;		\
	char		*name;					\
	shdr = (Elf32_Shdr*)(m + ehdr->e_shoff);		\
	if (ehdr->e_shstrndx != SHN_UNDEF) {			\
		int		i;				\
		strtab = shdr[ehdr->e_shstrndx].sh_offset;	\
		for (i=0, s=shdr; i<ehdr->e_shnum; i++,s++) {	\
			name = m + strtab + s->sh_name;		\
			if (!strncmp(name, ".text", 5)) {	\
				text_addr = s->sh_addr;		\
				text_size = s->sh_size;		\
				text_offset = s->sh_offset;	\
				break;				\
			}					\
		}						\
	}							\
	if (text_offset == 0) {					\
		fprintf(stderr, "Failed to find .text!\n");	\
		return 2;					\
	}

#define	DST2VADDR(x)	(x - m - text_offset + text_addr)

enum {
	MODE_READ,
	MODE_WRITE
};

#define	MMAP_FILE(mode, name)					\
	int		h, l;					\
	unsigned char	*m;					\
	if ((h = open(name, mode == MODE_WRITE ? 2: 0)) < 0) {	\
		fprintf(stderr, "Unable to open file!\n");	\
		return 2;					\
	}							\
	if ((l = lseek(h, 0, 2)) < 0) {				\
		fprintf(stderr, "lseek");			\
		return 2;					\
	}							\
	m = mmap(NULL, l,					\
		PROT_READ|(mode == MODE_WRITE ? PROT_WRITE : 0),\
		(mode == MODE_WRITE ? MAP_SHARED : MAP_PRIVATE),\
		h, 0);						\
	if (m == MAP_FAILED) {					\
		fprintf(stderr, "mmap");			\
		return 2;					\
	}
