/*
 * By using this file, you agree to the terms and conditions set
 * forth in the COPYING file which can be found at the top level
 * of this distribution.
 */
code_t	*code_ret;
uint8_t	*firstcall;

uint32_t crc_tab[256];

uint32_t crc32(unsigned char *block, unsigned int length)
{
   register unsigned long crc;
   unsigned long i;

	crc = 0xFFFFFFFF;
	for (i = 0; i < length; i++)
		crc = ((crc >> 8) & 0x00FFFFFF) ^ crc_tab[(crc ^ *block++) & 0xFF];
	return (crc ^ 0xFFFFFFFF);
}

void crc32_gentab(void)
{
	unsigned long crc, poly;
	int i, j;
	poly = 0xEDB88320L;
	for (i = 0; i < 256; i++) {
		crc = i;
		for (j = 8; j > 0; j--) {
			if (crc & 1)
				crc = (crc >> 1) ^ poly;
			else
				crc >>= 1;
		}
		crc_tab[i] = crc;
   	}
}

unsigned char *read_file(char *filename)
{
	int		h, l;
	unsigned char	*buf;
	if ((h = open(filename, 0)) < 0) {
		fprintf(stderr, "Failed to open file!\n");
		return NULL;
	}
	if ((l = lseek(h, 0, 2)) < 0 || lseek(h, 0, 0) != 0) {
		fprintf(stderr, "lseek\n");
		return NULL;
	}
	if ((buf = (unsigned char*)malloc(l)) == NULL) {
		fprintf(stderr, "oom\n");
		return NULL;
	}
	if (read(h, buf, l) != l) {
		fprintf(stderr, "Failed to read file!\n");
		return NULL;
	}
	return buf;
}

code_t *reassemble(uint8_t *ptr) {
	code_t *code = NULL;
	void reassemble2(uint8_t *ptr) {
		code_t	*c, *q;
		int	op_len;
		for(;;) {
			if (*ptr == 0xf4)
				return;
			for (c = code; c != NULL; c = c->next)
				if (c->src == ptr)
					return;
			op_len = mlde32(ptr);
			if (op_len <= 0)
				return;
			
			c = (code_t*)malloc(sizeof(code_t));
			c->src = ptr;
			c->jmpto = 0;
			c->len = op_len;
			c->next = NULL;
			if (code == NULL || c->src < code->src) {
				c->next	= code;
				code	= c;
			} else {
				q = code;
				while (q->next != NULL && q->next->src < c->src)
					q = q->next;
				c->next = q->next;
				q->next = c;
			}
			if (*ptr == 0xc3 || *ptr == 0xc2)
				return;
			if (*ptr == 0xe8 || *ptr == 0xe9 || (*ptr == 0x0f && (*(ptr + 1) & 0xf0) == 0x80)) {
				c->jmpto = ptr + op_len + *((int32_t*)(ptr + op_len - 4));
				if (*ptr == 0xe9) {
					if (*(ptr + 5) == 0xf4) {
						code_ret = c;
						c->len++;
						c->jmpto = 0;
					} else {
						ptr = c->jmpto;
						continue;
					}
				} else
					reassemble2(c->jmpto);
			}
			ptr += op_len;
		}
	}
	reassemble2(ptr);
	return code;
}

island_t *find_islands(uint8_t *start, uint8_t *end)
{
        island_t        *islands = NULL, *p, *tail = NULL;
        unsigned char   *ptr = start;
        int             op_len;
        while (ptr < end) {
		int	i;
                for (i = 0; i < 10; i++)
                        if (crc32(ptr, patterns[i].length) == patterns[i].crc32) {
				p = (island_t*)malloc(sizeof(island_t));
				p->offset = (uint32_t)(ptr + patterns[i].shift);
				p->length = patterns[i].length - patterns[i].shift;
				p->next = NULL;
				if (islands == NULL)
					islands = p;
				else
					tail->next = p;
				tail = p;
				ptr += patterns[i].length;
				continue;
			}
                if ((op_len = mlde32(ptr)) <= 0) {
                        fprintf(stderr, "Illegal instruction!\n");
                        return NULL;
                }
		if (firstcall == NULL && *ptr == 0xe8)
			firstcall = ptr;			
                ptr += op_len;
        }
	return islands;
}

void dump_code(code_t *code)
{
	int	i;
	code_t	*c;

	for (c = code; c != NULL; c = c->next) {
		printf("%08x: ", (uint32_t)c->src);
		for (i = 0; i < c->len; i++)
			printf("%02x ", c->src[i]);
		if (c->jmpto != 0)
			printf("-> %08x\n", (uint32_t)c->jmpto);
		else
			putchar('\n');
	}
}
