
DWORD _stdcall mail_it(LPVOID pv);

