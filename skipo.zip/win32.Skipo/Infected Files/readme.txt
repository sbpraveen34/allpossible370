These files is infected by Skipo virus so don't try to run them

this virus infect its folder only but also try to take care

pn.exe: Programmers' Notepad 

Debug Version:the entrypoint remain the same and the virus run in the middle of the program but you can find the proc by searching for
push ebp
mov ebp,esp
nop
nop
nop

so you can easily find the first decryptor and debug it 

SimpleWindow:created by me and infected with parameter infection epo

hope you enjoyed